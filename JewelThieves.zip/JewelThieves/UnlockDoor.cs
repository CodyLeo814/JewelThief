﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JewelThieves
{
    
        class UnlockDoor : Command
        {
            public UnlockDoor()
            {
                this.name = "unlock";
            }

            override
            public bool execute(Player player)
            {
                if (this.hasSecondWord())
                {
                    player.unlock(this.secondWord);
                }
                else
                {
                    player.outputMessage("\nUnlock What?");
                }
                return false;
            }
        }
    }
