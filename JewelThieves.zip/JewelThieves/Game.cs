﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JewelThieves
{
    public class Game
    {
        Player player;
        Parser parser;
        bool playing;



        public Game()
        {
            playing = false;
            parser = new Parser(new CommandWords());
            player = new Player(GameWorld.Instance.Entrance);
        }
        public void play()
        {

            // Enter the main command loop.  Here we repeatedly read commands and
            // execute them until the game is over.

            bool finished = false;
            while (!finished)
            {
                Console.Write("\n>");
                Command command = parser.parseCommand(Console.ReadLine());
                if (command == null)
                {
                    Console.WriteLine("You take a moment to stare at the gem filled cave pondering your next move.");
                }
                else
                {
                    finished = command.execute(player);
                }
            }
        }


        public void start()
        {
            playing = true;
            player.outputMessage(welcome());
        }

        public void end()
        {
            playing = false;
            player.outputMessage(goodbye());
        }

        public string welcome()
        {

            return "You are on a teasure hunt through the caves of an enemy kingdom find and collect as many gems as you can carry\n ******Type 'help' for instructions.****** " + player.currentRoom.description();
        }

        public string goodbye()
        {
            player.displayInventory();
            return "\nYou ranaway with alot of precious metals and gems from the enemy kingdom good job  \nGoodbye Player\n";
        }

    }
}
