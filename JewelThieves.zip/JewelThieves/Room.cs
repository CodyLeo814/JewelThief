﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JewelThieves
{

    public class Room
    {
        private Dictionary<string, Door> exits;
        private Dictionary<string, DefineItem> items;

        private string _tag;
        public string tag
        {
            get
            {
                return _tag;
            }
            set
            {
                _tag = value;
            }
        }
        public string shortName { get; set; }

        public Room() : this("No Tag")
        {

        }

        public Room(string tag) : this(tag, "generic_connected_area")
        {
        }

        public Room(string tag, string shortName)
        {
            exits = new Dictionary<string, Door>();
            items = new Dictionary<string, DefineItem>();
            this.tag = tag;
            this.shortName = shortName;
        }

        public void setExit(string exitName, Door door)
        {
            exits[exitName] = door;
        }

        public Door getExit(string exitName)
        {
            Door door = null;
            exits.TryGetValue(exitName, out door);
            return door;
        }

        public void drop(DefineItem item)
        {
            items[item.Name] = item;
        }

        public DefineItem pickup(string itemName)
        {
            DefineItem item = null;
            items.TryGetValue(itemName, out item);
            items.Remove(itemName);
            return item;
        }

        public string getExits()
        {
            string exitNames = "\nRooms -";
            Dictionary<string, Door>.KeyCollection keys = exits.Keys;
            foreach (string exitName in keys)
            {
                exitNames += " " + exitName; //+ " |";
            }

            return exitNames;
        }

        public string getItems()
        {
            DefineItem item = null;
            string itemNames = "Items -";
            Dictionary<string, DefineItem>.KeyCollection keys = items.Keys;
            foreach (string itemName in keys)
            {
                itemNames += " " + itemName + " |";
            }

            return itemNames;
        }


        public string description()
        {
            return "\nYou have entered the " + this.tag + ".\nWhere would you like to go?:" + this.getExits() + "\n" + this.getItems();
        }
    }
}
