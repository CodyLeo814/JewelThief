﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JewelThieves
{
    class PickupItem : Command
    {
        public PickupItem()
        {
            this.name = "pickup";
        }

        override
        public bool execute(Player player)
        {
            if (this.hasSecondWord())
            {
                player.pickup(this.secondWord);
            }
            else
            {
                player.outputMessage("\nPickup What?");
            }
            return false;
        }
    }
}
