﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JewelThieves
{
    public class Door : LockDoor
    {
        private Room roomA;
        private Room roomB;
        private bool closed;
        public bool Closed
        {
            get
            {
                return closed;
            }
            set
            {
                if (theLock != null)
                {
                    if (theLock.MayClose())
                    {
                        closed = value;
                    }
                }
                else
                {
                    closed = true;
                }
            }
        }
        public bool Open
        {
            get
            {
                return !closed;
            }
            set
            {
                if (theLock != null)
                {
                    if (theLock.MayOpen())
                    {
                        closed = !value;
                    }
                }
                else
                {
                    closed = !value;
                }
            }
        }

        private LockDoor theLock;
        public Door(Room roomA, Room roomB)
        {
            this.roomA = roomA;
            this.roomB = roomB;
            closed = false;
            theLock = new lockDefault();
        }

        public Room room(Room from)
        {
            if (roomA == from)
            {
                return roomB;
            }
            else
            {
                return roomA;
            }
        }

        public void Lock()
        {
            if (theLock != null)
            {
                theLock.Lock();
            }
        }

        public void Unlock()
        {
            if (theLock != null)
            {
                theLock.Unlock();
            }
        }

        public bool IsLocked()
        {
            if (theLock != null)
            {
                return theLock.IsLocked();
            }
            else
            {
                return false;
            }
        }

        public bool IsUnlocked()
        {
            if (theLock != null)
            {
                return theLock.IsUnlocked();
            }
            else
            {
                return true;
            }
        }

        public bool MayOpen()
        {
            if (theLock != null)
            {
                return theLock.MayOpen();
            }
            else
            {
                return true;
            }
        }

        public bool MayClose()
        {
            if (theLock != null)
            {
                return theLock.MayClose();
            }
            else
            {
                return true;
            }
        }

        public static Door connect(Room room1, Room room2)
        {
            /*if(Closed == true)
            {
                Door door = new Door(room1, room2);
                room1.setExit("closed_door", door);
                room2.setExit("closed_door", door);
                return door;
            }
            else if(Lock.equals(true))
            {
                Door door = new Door(room1, room2);
                room1.setExit("locked_door", door);
                room2.setExit("locked_door", door);
                return door;
            }*/
            //else
            //{
            Door door = new Door(room1, room2);
            room1.setExit(room2.shortName, door);
            room2.setExit(room1.shortName, door);
            return door;
            //}
        }

    }
}
