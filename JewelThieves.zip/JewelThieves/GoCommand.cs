﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JewelThieves
{
    class GoCommand : Command
    {
        public GoCommand() : base()
        {
            this.name = "go";
        }

        override
        public bool execute(Player player)
        {
            if (this.hasSecondWord())
            {
                player.walkTo(this.secondWord);
            }
            else
            {
                player.outputMessage("\nGo Where?");
            }
            return false;
        }
    }
}
