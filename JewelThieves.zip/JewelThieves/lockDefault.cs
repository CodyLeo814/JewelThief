﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JewelThieves
{
    class lockDefault : LockDoor
    {
        private bool locked;
        public lockDefault()
        {
            locked = false;
        }

        public void Lock()
        {
            locked = true;
        }

        public void Unlock()
        {
            locked = false;
        }

        public bool IsLocked()
        {
            return locked;
        }

        public bool IsUnlocked()
        {
            return !locked;
        }

        public bool MayOpen()
        {
            return !locked;
        }

        public bool MayClose()
        {
            return true;
        }
    }
}
