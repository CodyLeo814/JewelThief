﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JewelThieves
{
    
        public class Player
        {
            private Room _currentRoom = null;
            private Dictionary<string, DefineItem> inventory;
            private Stack<Room> stack;
            private float totalI;
            private float maxW;
            private float gemworth;
            public Room currentRoom
            {
                get
                {
                    return _currentRoom;
                }
                set
                {
                    _currentRoom = value;
                }
            }

            public Player(Room room)//GameOutput output
            {
                _currentRoom = room;
                inventory = new Dictionary<string, DefineItem>();
                stack = new Stack<Room>();
                stack.Push(_currentRoom);
                totalI = 0;
                maxW = 15;
                gemworth = 0;
            }

            public void setCurrentRoom(Room room)
            {
                _currentRoom = room;
            }

            public Room getCurrentRoom()
            {
                return _currentRoom;
            }

            public void walkTo(string direction)
            {
                Door door = this._currentRoom.getExit(direction);
                if (door != null)
                {
                    if (door.Open)
                    {
                        Room nextRoom = door.room(currentRoom);
                        this._currentRoom = door.room(this._currentRoom);
                        // Player posts a notification PlayerEnteredRoom
                        NotificationCenter.Instance.postNotification(new Notification("PlayerEnteredRoom", this));
                        setCurrentRoom(nextRoom);
                        this.outputMessage("\n" + this._currentRoom.description());
                        //adds room to stack for back command
                        stack.Push(_currentRoom);
                    }
                    else
                    {
                        this.outputMessage("\nThe door to " + direction + " is closed.");
                    }
                }
                else
                {
                    this.outputMessage("\nThere is no door called " + direction);
                }
            }

            //back command that pushes you back a room when using the command
            public void back()
            {
                try
                {
                    if (stack.Peek() == _currentRoom)
                    {
                        stack.Pop();
                    }
                    Room nextRoom = stack.Pop();
                    setCurrentRoom(nextRoom);
                    this.outputMessage(nextRoom.description());
                    stack.Push(nextRoom);
                }
                catch (System.InvalidOperationException)
                {
                    this.outputMessage("\nSeriously walking through walls is not going to work they are a solid object.'\nYou have arrived back after hitting your head of course.");
                    this.outputMessage(this._currentRoom.description());
                }
            }

            public void open(String doorName)
            {
                Door door = this._currentRoom.getExit(doorName);
                if (door != null)
                {
                    if (door.MayOpen())
                    {
                        door.Open = true;
                        this.outputMessage("\nThe door to the " + doorName + " is now open.");
                    }
                    else
                    {
                        if (door.IsLocked())
                        {
                            this.outputMessage("\nThe door to the " + doorName + " is locked.");

                        }
                    }
                }
                else
                {
                    this.outputMessage("\nThere is no door called " + doorName);
                }
            }

            public void unlock(String doorName)
            {
                Door door = this._currentRoom.getExit(doorName);
                if (door != null)
                {
                    door.Unlock();
                    this.outputMessage("\nThe door to the " + doorName + " is now unlocked.");
                }
                else
                {
                    this.outputMessage("\nThere is no door called " + doorName);
                }
            }

            public void give(DefineItem item)
            {
                //checks weight of item before adding it to inventory
                if (totalI + item.Weight <= maxW)
                {
                    inventory[item.Name] = item;
                    totalI += item.Weight;
                    gemworth += item.worth;
                    this.outputMessage("You decided to pickup the " + item.Name + " Keep an eye on your inventory weight");
                }
                else
                {
                    this.outputMessage("You're carrying alot there, you should try putting something down first.\n According to the Kingdoms rules if an item is dropped in this cave the Rulers destroy it");
                }
            }

            public DefineItem take(string itemName)
            {
                DefineItem item = null;
                inventory.TryGetValue(itemName, out item);
                inventory.Remove(itemName);
                return item;
            }

            public void pickup(string itemName)
            {
                DefineItem item = currentRoom.pickup(itemName);
                if (item != null)
                {
                    give(item);
                }
                else
                {
                    outputMessage("The item " + itemName + " does not exist in the room");
                }
            }

            public void drop(string itemName)
            {
                DefineItem item = take(itemName);
                if (item != null)
                {
                    currentRoom.drop(item);
                    totalI -= item.Weight;
                    gemworth -= item.worth;
                    outputMessage("You decided to abandon the " + item.Name + " you can not take it thief rule #1");
                }
                else
                {
                    outputMessage("The item " + itemName + " is not in your inventory");
                }
            }



            public void displayInventory()
            {
                string itemNames = "Items: ";
                Dictionary<string, DefineItem>.KeyCollection keys = inventory.Keys;
                foreach (string itemName in keys)
                {
                    itemNames += " " + itemName;
                }
                this.outputMessage("Inventory => " + itemNames);
                this.outputMessage("Current Carying Weight: " + totalI + " | Max Carrying Weight: " + maxW);
                this.outputMessage("Current Gem Value is: " + gemworth);
            }



            public void outputMessage(string message)
            {
                Console.WriteLine(message);
            }
        }
    }

