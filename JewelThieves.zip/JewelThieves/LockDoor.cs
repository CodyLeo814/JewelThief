﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JewelThieves
{
    public interface LockDoor
    {
        void Lock();
        void Unlock();
        bool IsLocked();
        bool IsUnlocked();
        bool MayOpen();
        bool MayClose();
    }
}
