﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JewelThieves
{
    class DropItem : Command
    {
        public DropItem()
        {
            this.name = "drop";
        }

        override
        public bool execute(Player player)
        {
            if (this.hasSecondWord())
            {
                player.drop(this.secondWord);
            }
            else
            {
                player.outputMessage("\nDrop What?");
            }
            return false;
        }
    }
}
