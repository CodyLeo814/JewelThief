﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JewelThieves
{

    class BackCommand : Command
    {
        public BackCommand() : base()
        {
            this.name = "back";
        }

        override
        public bool execute(Player player)
        {
            if (this.hasSecondWord())
            {
                string direction = secondWord;
                player.outputMessage("The gems respond to you by showing you a flash of words 'only back' ");
            }
            else
            {
                player.outputMessage("\nYou turn around and go back a room");
                player.back();
            }
            return false;
        }
    }

}
