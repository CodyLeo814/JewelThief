﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JewelThieves
{

    public interface DefineItem
    {
        string Name { get; set; }
        float Weight { get; set; }
        float worth { get; set; }
        void AddDecorator(DefineItem decorator);
        string ToString();
    }
}
