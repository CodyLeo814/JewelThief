﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JewelThieves
{
    class Inventory : Command
    {
        public Inventory()
        {
            this.name = "inventory";
        }

        override
        public bool execute(Player player)
        {
            if (!this.hasSecondWord())
            {
                player.displayInventory();
            }
            else
            {
                player.outputMessage("\nI cannot inventory " + this.secondWord);
            }
            return false;
        }

    }
}
