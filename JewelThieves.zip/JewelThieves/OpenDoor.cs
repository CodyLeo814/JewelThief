﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JewelThieves
{
    class OpenDoor : Command
    {
        public OpenDoor()
        {
            this.name = "open";
        }

        override
        public bool execute(Player player)
        {
            if (this.hasSecondWord())
            {
                player.open(this.secondWord);
            }
            else
            {
                player.outputMessage("\nOpen What?");
            }
            return false;
        }
    }
}
