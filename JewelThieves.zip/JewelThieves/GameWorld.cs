﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace JewelThieves
{
    public class GameWorld
    {
        static private GameWorld _instance;
        static public GameWorld Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new GameWorld();
                return _instance;
            }
        }
        private Room _entrance;
        private ArrayList keys = new ArrayList(14); //keys for values in each room
        public Room Entrance { get { return _entrance; } }
        private Room trigger;
        private Room connectionRoom;
        private List<Room> hotList;
        private GameWorld()
        {
            hotList = new List<Room>();
            _entrance = CreateWorld();
            // GameWorld subscribes to the notification PlayerEnteredRoom
            NotificationCenter.Instance.addObserver("You have entered", playerEnteredRoom);
        }
        private Room CreateWorld()
        {

            //Rooms full Description, in dictionary preparing for randomization
            IDictionary<int, string> dictRoomFull = new Dictionary<int, string>();
            dictRoomFull.Add(1, "Entrance");
            dictRoomFull.Add(2, "WhiteDiamondCave");
            dictRoomFull.Add(3, "BlueDiamondCave");
            dictRoomFull.Add(4, "YellowDiamondCave");
            dictRoomFull.Add(5, "SapphireCave");
            dictRoomFull.Add(6, "EmeraldCave");
            dictRoomFull.Add(7, "RubyCave");
            dictRoomFull.Add(8, "PearlRoom");
            dictRoomFull.Add(9, "EmptyRoom");
            dictRoomFull.Add(10, "QuatrzCave");
            dictRoomFull.Add(11, "Vault");
            dictRoomFull.Add(12, "ThroneRoom");
            dictRoomFull.Add(13, "AmaythistCave");
            dictRoomFull.Add(14, "PeridotCave");



            IDictionary<int, string> dictRoomShort = new Dictionary<int, string>();
            dictRoomShort.Add(1, "Entrance");
            dictRoomShort.Add(2, "WhiteDiamond");
            dictRoomShort.Add(3, "BlueDiamond");
            dictRoomShort.Add(4, "YellowDiamond");
            dictRoomShort.Add(5, "Sapphire");
            dictRoomShort.Add(6, "Emerald");
            dictRoomShort.Add(7, "Ruby");
            dictRoomShort.Add(8, "Pearl");
            dictRoomShort.Add(9, "Empty");
            dictRoomShort.Add(10, "Quartz");
            dictRoomShort.Add(11, "Vault");
            dictRoomShort.Add(12, "ThroneRoom");
            dictRoomShort.Add(13, "Amaythis");
            dictRoomShort.Add(14, "Peridot");

            IDictionary<int, string> toBePickedup = new Dictionary<int, string>();
            toBePickedup.Add(1, "YellowGem");
            toBePickedup.Add(2, "BlueGem");
            toBePickedup.Add(3, "WhiteGem");
            toBePickedup.Add(4, "Emerald");
            toBePickedup.Add(5, "Sapphire");
            toBePickedup.Add(6, "DiamondRing");
            toBePickedup.Add(7, "CrystalShard");
            toBePickedup.Add(8, "CrystalShard");
            toBePickedup.Add(9, "CrystalShard");
            toBePickedup.Add(10, "CrystalShard");
            toBePickedup.Add(11, "PinkPearl");
            toBePickedup.Add(12, "YellowPearl");
            toBePickedup.Add(13, "BluePearl");
            toBePickedup.Add(14, "WhitePearl");
            toBePickedup.Add(15, "WhiteDiamond");
            toBePickedup.Add(16, "BlueDiamond");
            toBePickedup.Add(17, "YellowDiamond");
            toBePickedup.Add(18, "GemShard");
            toBePickedup.Add(19, "GemShard");
            toBePickedup.Add(20, "GemShard");
            toBePickedup.Add(21, "Crown");
            toBePickedup.Add(22, "PinkDiamond");
            toBePickedup.Add(23, "Gold");
            toBePickedup.Add(24, "Spinel");
            toBePickedup.Add(25, "Ruby");
            toBePickedup.Add(26, "RainbowQuartz");
            toBePickedup.Add(27, "RoseQuartz");
            toBePickedup.Add(28, "Silver");
            // item weight
            IDictionary<int, int> itemWeight = new Dictionary<int, int>();
            itemWeight.Add(1, 1);
            itemWeight.Add(2, 1);
            itemWeight.Add(3, 1);
            itemWeight.Add(4, 2);
            itemWeight.Add(5, 2);
            itemWeight.Add(6, 3);
            itemWeight.Add(7, 1);
            itemWeight.Add(8, 1);
            itemWeight.Add(9, 1);
            itemWeight.Add(10, 1);
            itemWeight.Add(11, 3);
            itemWeight.Add(12, 3);
            itemWeight.Add(13, 3);
            itemWeight.Add(14, 3);
            itemWeight.Add(15, 3);
            itemWeight.Add(16, 3);
            itemWeight.Add(17, 3);
            itemWeight.Add(18, 1);
            itemWeight.Add(19, 1);
            itemWeight.Add(20, 1);
            itemWeight.Add(21, 3);
            itemWeight.Add(22, 5);
            itemWeight.Add(23, 3);
            itemWeight.Add(24, 1);
            itemWeight.Add(25, 2);
            itemWeight.Add(26, 1);
            itemWeight.Add(27, 1);
            itemWeight.Add(28, 2);

            // items worth 
            IDictionary<int, int> Itemcost = new Dictionary<int, int>();
            Itemcost.Add(1, 100);
            Itemcost.Add(2, 100);
            Itemcost.Add(3, 100);
            Itemcost.Add(4, 10000);
            Itemcost.Add(5, 10000);
            Itemcost.Add(6, 445000);
            Itemcost.Add(7, 50);
            Itemcost.Add(8, 50);
            Itemcost.Add(9, 50);
            Itemcost.Add(10, 50);
            Itemcost.Add(11, 2000);
            Itemcost.Add(12, 2500);
            Itemcost.Add(13, 3000);
            Itemcost.Add(14, 1000);
            Itemcost.Add(15, 300000);
            Itemcost.Add(16, 500000);
            Itemcost.Add(17, 200000);
            Itemcost.Add(18, 500);
            Itemcost.Add(19, 500);
            Itemcost.Add(20, 500);
            Itemcost.Add(21, 39000000);
            Itemcost.Add(22, 10000000);
            Itemcost.Add(23, 100000);
            Itemcost.Add(24, 500);
            Itemcost.Add(25, 1500);
            Itemcost.Add(26, 900);
            Itemcost.Add(27, 350);
            Itemcost.Add(28, 1000);

            Room entrance = new Room("caves are filled with gems and other precious materials", "entrance");

            int index = randRoomName(dictRoomShort.Count);
            int index2 = index + dictRoomShort.Count;
            Room vault = new Room(dictRoomFull[index], dictRoomShort[index]);
            Item vault1 = new Item(toBePickedup[index], itemWeight[index], Itemcost[index]);



            index = randRoomName(dictRoomShort.Count);
            index2 = index + dictRoomShort.Count;
            Room Peridot = new Room(dictRoomFull[index], dictRoomShort[index]);
            Item P1 = new Item(toBePickedup[index], itemWeight[index], Itemcost[index]);


            index = randRoomName(dictRoomShort.Count);
            index2 = index + dictRoomShort.Count;
            Room white = new Room(dictRoomFull[index], dictRoomShort[index]);
            Item white1 = new Item(toBePickedup[index], itemWeight[index], Itemcost[index]);
            Item white2 = new Item(toBePickedup[index2], itemWeight[index2], Itemcost[index2]);


            index = randRoomName(dictRoomShort.Count);
            index2 = index + dictRoomShort.Count;
            Room Blue = new Room(dictRoomFull[index], dictRoomShort[index]);
            Item Blue1 = new Item(toBePickedup[index], itemWeight[index], Itemcost[index]);
            Item Blue2 = new Item(toBePickedup[index2], itemWeight[index2], Itemcost[index2]);


            index = randRoomName(dictRoomShort.Count);
            index2 = index + dictRoomShort.Count;
            Room Yellow = new Room(dictRoomFull[index], dictRoomShort[index]);
            Item Yellow1 = new Item(toBePickedup[index], itemWeight[index], Itemcost[index]);
            Item Yellow2 = new Item(toBePickedup[index2], itemWeight[index2], Itemcost[index2]);


            index = randRoomName(dictRoomShort.Count);
            index2 = index + dictRoomShort.Count;
            Room Sapphire = new Room(dictRoomFull[index], dictRoomShort[index]);
            Item Sap1 = new Item(toBePickedup[index], itemWeight[index], Itemcost[index]);
            Item Sap2 = new Item(toBePickedup[index2], itemWeight[index2], Itemcost[index2]);


            index = randRoomName(dictRoomShort.Count);
            index2 = index + dictRoomShort.Count;
            Room Emerald = new Room(dictRoomFull[index], dictRoomShort[index]);
            Item Em1 = new Item(toBePickedup[index], itemWeight[index], Itemcost[index]);
            Item Em2 = new Item(toBePickedup[index2], itemWeight[index2], Itemcost[index2]);


            index = randRoomName(dictRoomShort.Count);
            index2 = index + dictRoomShort.Count;
            Room Ruby = new Room(dictRoomFull[index], dictRoomShort[index]);
            Item Ruby1 = new Item(toBePickedup[index], itemWeight[index], Itemcost[index]);
            Item Ruby2 = new Item(toBePickedup[index2], itemWeight[index2], Itemcost[index2]);


            index = randRoomName(dictRoomShort.Count);
            index2 = index + dictRoomShort.Count;
            Room Pearl = new Room(dictRoomFull[index], dictRoomShort[index]);
            Item Pearl1 = new Item(toBePickedup[index], itemWeight[index], Itemcost[index]);
            Item Pearl2 = new Item(toBePickedup[index], itemWeight[index], Itemcost[index]);


            index = randRoomName(dictRoomShort.Count);
            index2 = index + dictRoomShort.Count;
            Room Empty = new Room(dictRoomFull[index], dictRoomShort[index]);
            Item E1 = new Item(toBePickedup[index], itemWeight[index], Itemcost[index]);
            Item E2 = new Item(toBePickedup[index2], itemWeight[index2], Itemcost[index2]);


            index = randRoomName(dictRoomShort.Count);
            index2 = index + dictRoomShort.Count;
            Room Quartz = new Room(dictRoomFull[index], dictRoomShort[index]);
            Item Q1 = new Item(toBePickedup[index], itemWeight[index], Itemcost[index]);
            Item Q2 = new Item(toBePickedup[index2], itemWeight[index2], Itemcost[index2]);


            index = randRoomName(dictRoomShort.Count);
            index2 = index + dictRoomShort.Count;
            Room Throne = new Room(dictRoomFull[index], dictRoomShort[index]);
            Item Throne1 = new Item(toBePickedup[index], itemWeight[index], Itemcost[index]);
            Item Throne2 = new Item(toBePickedup[index2], itemWeight[index2], Itemcost[index2]);

            index = randRoomName(dictRoomShort.Count);
            index2 = index + dictRoomShort.Count;
            Room Amaythis = new Room(dictRoomFull[index], dictRoomShort[index]);
            Item A1 = new Item(toBePickedup[index], itemWeight[index], Itemcost[index]);
            Item A2 = new Item(toBePickedup[index2], itemWeight[index2], Itemcost[index2]);

            // drops the items
            white.drop(white1);
            white.drop(white2);

            Blue.drop(Blue1);
            Blue.drop(Blue2);

            Yellow.drop(Yellow1);
            Yellow.drop(Yellow2);

            Sapphire.drop(Sap1);
            Sapphire.drop(Sap2);

            Emerald.drop(Em1);
            Emerald.drop(Em2);

            Ruby.drop(Ruby1);
            Ruby.drop(Ruby2);

            Pearl.drop(Pearl1);
            Pearl.drop(Pearl2);

            Empty.drop(E1);
            Empty.drop(E2);


            Quartz.drop(Q1);
            Quartz.drop(Q2);

            Throne.drop(Throne1);
            Throne.drop(Throne2);

            Amaythis.drop(A1);
            Amaythis.drop(A2);

            vault.drop(vault1);

            Peridot.drop(P1);

            // setting the board

            Door door = Door.connect(Throne, vault);
            door.Closed = true;
            door.Lock();

            door = Door.connect(Throne, white);
            door.Closed = true;
            door.Lock();

            door = Door.connect(white, Blue);

            door = Door.connect(white, Yellow);

            door = Door.connect(white, Empty);
            door.Closed = true;
            door.Lock();

            door = Door.connect(Empty, Sapphire);

            door = Door.connect(Sapphire, Quartz);

            door = Door.connect(Quartz, Pearl);

            door = Door.connect(Quartz, Amaythis);
            door.Closed = true;
            door.Lock();

            door = Door.connect(Pearl, entrance);

            door = Door.connect(Pearl, Emerald);

            door = Door.connect(entrance, Peridot);

            door = Door.connect(Emerald, Ruby);
            door.Closed = true;
            door.Lock();

            trigger = entrance;
            connectionRoom = entrance;




            return entrance;
        }
        public void playerEnteredRoom(Notification notification)
        {
            Player player = (Player)notification.Object;
            if (player.currentRoom == trigger)
            {
                Console.WriteLine("Player entered the trigger room");
            }

            //if(hotList.Contains(player.currentRoom))
            if (hotList.Count > 0 && hotList[0] == player.currentRoom)
            {
                hotList.Remove(player.currentRoom);
                if (hotList.Count == 0)
                {
                    player.outputMessage("\n<<<All the rooms have been visited.>>>\n");
                }
            }
        }

        //generates a brand new random number
        public int trueRand(int max)
        {
            Random r = new Random();
            int randNum = r.Next(1, max + 1);

            return randNum;
        }

        //doesn't allow random number to occur more than once.
        public int randRoomName(int max)
        {
            int key = trueRand(max);
            while (this.keys.Contains(key))
                key = trueRand(max);
            this.keys.Add(key);
            return key;

        }
    }
}
