﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JewelThieves
{
    class HelpCommand : Command
    {
        CommandWords words;

        public HelpCommand() : this(new CommandWords())
        {
        }

        public HelpCommand(CommandWords commands) : base()
        {
            words = commands;
            this.name = "help";
        }

        override
        public bool execute(Player player)
        {
            if (this.hasSecondWord())
            {
                player.outputMessage("\nI cannot help you with " + this.secondWord);
            }
            else
            {
                player.outputMessage("\nYou remember seeing a note at the entry at the caves telling you. \n\nYou can use these commands: " + words.description() + "\nTo leave the cave with your treasure press quit.\nTry the high score you are a master thief right?");
            }
            return false;
        }

    }
}
