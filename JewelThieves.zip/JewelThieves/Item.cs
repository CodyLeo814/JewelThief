﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JewelThieves
{
    class Item : DefineItem
    {

        public string Name { get; set; }
        private float weight;
        public float Weight
        {
            get
            {
                return weight + (decorator == null ? 0 : decorator.Weight);
                /*
                if(decorator == null)
                {
                    return weight;
                }
                else
                {
                    return weight + decorator.Weight;
                }
                */
            }
            set
            {
                weight = value;
            }
        }
        private float Worth;

        public float worth { get; set; }




        private DefineItem decorator;

        public Item() : this("UnNamed")
        {
        }

        public Item(string itemName) : this(itemName, 1, 0)
        {

        }

        // Designated constructor
        public Item(string itemName, float itemWeight, float itemWorth)
        {
            this.Name = itemName;
            this.Weight = itemWeight;
            this.worth = itemWorth;
            this.decorator = null;
        }

        public void AddDecorator(DefineItem item)
        {
            if (decorator == null)
            {
                decorator = item;
            }
            else
            {
                this.decorator.AddDecorator(item);
            }
        }

        override
        public string ToString()
        {
            return Name + " - Weight: " + Weight;
        }
    }
}
